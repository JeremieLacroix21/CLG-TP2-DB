--     Noms : Gabriel Fournier-Cloutier & Jérémie Lacroix
--    Date : 2019-03-29
--  Groupe : 02
-- Fichier : Package GestionQuestions
--------------------------------------
--------------------
-- PACKAGE
--------------------
create or replace PACKAGE GESTIONQUESTIONS AS
    TYPE ENR_QUESTION IS REF CURSOR;
    TYPE ENR_REPONSE IS REF CURSOR;
    
    -- Insertion d'une nouvelle question (retourne l'ID attribu� dans P_numQuestion)
    PROCEDURE InsertQuestion
    (
        P_numQuestion IN OUT Questions.numQuestion%TYPE,
        P_enonce Questions.enonce%TYPE,
        P_codeCategorie Categories.codeCategorie%TYPE
    );
    
    -- Insertion d'une nouvelle reponse
    PROCEDURE InsertReponse 
    (
        P_numReponse Reponses.numReponse%TYPE,
        P_description Reponses.description%TYPE,
        P_estBonne Reponses.estBonne%TYPE,
        P_numQuestion Questions.numQuestion%TYPE
    );
    
    -- Remet le flag repondu de toute les questions � faux
    PROCEDURE ResetQuestionsRepondues;
    
    -- Set le flag repondu d'une question
    PROCEDURE SetRepondu
    (
        P_numQuestion Questions.numQuestion%TYPE,
        P_nouvRepondu Questions.repondu%TYPE
    );
    
    -- Retourne un ID unique pour la prochaine question d'une certaine cat�gorie
    FUNCTION GetProchainID
    (
        P_codeCategorie Categories.codeCategorie%TYPE
    ) RETURN Questions.numQuestion%TYPE; 
    
    -- Retourne une question d'une cat�gorie au hasard dont le flag repondu est faux
    FUNCTION GetQuestionHasard
    (
        P_codeCategorie Categories.codeCategorie%TYPE
    ) RETURN ENR_QUESTION;
    
    -- Retourne toute les r�ponses associ�es � une question
    FUNCTION GetReponses
    (
        P_numQuestion Questions.numQuestion%TYPE
    ) RETURN ENR_REPONSE;
    
    -- Retourne 'O' si la reponses est bonne, 'N' si elle ne l'est pas
    FUNCTION ValiderReponse
    (
        P_numReponse Reponses.numReponse%TYPE
    ) RETURN Reponses.estBonne%TYPE;
    
END GESTIONQUESTIONS;

--------------------
-- BODY PACKAGE
--------------------
create or replace PACKAGE BODY GESTIONQUESTIONS AS
 
  PROCEDURE InsertReponse 
    (
        P_numReponse Reponses.numReponse%TYPE, 
        P_description Reponses.description%TYPE,
        P_estBonne Reponses.estBonne%TYPE,
        P_numQuestion Questions.numQuestion%TYPE
    ) AS 
  BEGIN
    INSERT INTO Reponses VALUES(TRIM(P_numReponse), P_description, P_estBonne, P_numQuestion);
  END InsertReponse;

  PROCEDURE ResetQuestionsRepondues AS 
  BEGIN
    UPDATE Questions SET repondu = 'N';
  END ResetQuestionsRepondues;

  PROCEDURE SetRepondu
    (
        P_numQuestion Questions.numQuestion%TYPE,
        P_nouvRepondu Questions.repondu%TYPE
    ) AS
  BEGIN
    UPDATE Questions SET repondu = P_nouvRepondu WHERE numQuestion = P_numQuestion;
  END SetRepondu;
    
  PROCEDURE InsertQuestion
    (
        P_numQuestion IN OUT Questions.numQuestion%TYPE,
        P_enonce Questions.enonce%TYPE,
        P_codeCategorie Categories.codeCategorie%TYPE
    ) AS
  BEGIN
    P_numQuestion := GetProchainID(P_codeCategorie);
    INSERT INTO Questions VALUES(P_numQuestion, P_enonce, 'N', P_codeCategorie);
  END InsertQuestion;
    
  FUNCTION GetProchainID
    (
        P_codeCategorie Categories.codeCategorie%TYPE
    ) RETURN Questions.numQuestion%TYPE AS
    resultat Varchar2(20);
    seqNumQuestion Varchar2(20);
  BEGIN
    IF P_codeCategorie = 'G' THEN -- Histoire
        SELECT SEQ_V_numQuestion.NEXTVAL INTO seqNumQuestion FROM Dual;
    ELSIF P_codeCategorie = 'B' THEN -- Geographie
        SELECT SEQ_B_numQuestion.NEXTVAL INTO seqNumQuestion FROM Dual;
    ELSIF P_codeCategorie = 'O' THEN -- Sport
        SELECT SEQ_O_numQuestion.NEXTVAL INTO seqNumQuestion FROM Dual;
    ELSIF P_codeCategorie = 'P' THEN -- Art - Culture
        SELECT SEQ_M_numQuestion.NEXTVAL INTO seqNumQuestion FROM Dual;
    ELSE
        RAISE_APPLICATION_ERROR(-20002, 'Categorie invalide');
    END IF;
    resultat := P_codeCategorie||seqNumQuestion;
    RETURN resultat;
  END GetProchainID;
  
  FUNCTION GetQuestionHasard
    (
        P_codeCategorie Categories.codeCategorie%TYPE
    ) RETURN ENR_QUESTION AS
    resultat ENR_QUESTION;
    randRowNum Number;
  BEGIN
    OPEN resultat FOR SELECT numquestion, enonce, repondu, codeCategorie FROM (
        SELECT numquestion, enonce, repondu, codeCategorie, ROWNUM as num FROM Questions WHERE codeCategorie = P_codeCategorie AND repondu = 'N'
    ) WHERE num = (
        SELECT FLOOR(DBMS_RANDOM.Value(1, nbQuestionsDispos)) AS rand FROM (
            SELECT COUNT(numQuestion) AS nbQuestionsDispos FROM Questions WHERE codeCategorie = P_codeCategorie AND repondu = 'N'
        )
    );
    RETURN resultat; 
    CLOSE resultat;
  END GetQuestionHasard;

  FUNCTION GetReponses
    (
        P_numQuestion Questions.numQuestion%TYPE
    ) RETURN ENR_REPONSE AS
    resultat ENR_REPONSE;
  BEGIN
    OPEN resultat FOR SELECT * FROM Reponses WHERE P_numQuestion = numQuestion;
    RETURN resultat;
    CLOSE resultat;
  END GetReponses;

  FUNCTION ValiderReponse
    (
        P_numReponse Reponses.numReponse%TYPE
    ) RETURN Reponses.estBonne%TYPE AS
    resultat Reponses.estBonne%TYPE;
  BEGIN
    SELECT estBonne INTO resultat FROM Reponses WHERE P_numReponse = numReponse;
    RETURN resultat;
  END ValiderReponse;

END GESTIONQUESTIONS;
