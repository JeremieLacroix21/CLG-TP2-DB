--     Noms : Gabriel Fournier-Cloutier & Jérémie Lacroix
--    Date : 2019-03-29
--  Groupe : 02
-- Fichier : Package Statistiques
--------------------------------------
--------------------
-- PACKAGE
--------------------
create or replace PACKAGE STATISTIQUES AS
    TYPE ENR_SCORE IS REF CURSOR;
    TYPE ENR_CATEGORIE IS REF CURSOR;
    
    -- Incr�mente le score d'un joueur pour une cat�gorie et met le flag gagnee � true
    PROCEDURE IncrScore
    (
        P_codeCategorie Categories.codeCategorie%TYPE,
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    );  
    
    -- Remet le flag gagnee pour chaque cat�gorie pour chaque joueur � false
    PROCEDURE ResetCategoriesGagnee;
    
    -- Retourne les scores d'un joueur pour chaque cat�gories
    FUNCTION GetScoresJoueur
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_SCORE; 
    
    -- Retourne les donn�es suivantes : nom du joueur, prenom du joueur, les noms des cat�gories qu'il a gagn�
    FUNCTION GetCategoriesGagnees
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE;
    
    -- Retourne la cat�gorie la plus faible d'un joueur
    FUNCTION GetCategorieFaible 
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE;
    
    -- Retourne la cat�gorie la plus forte d'un joueur
    FUNCTION GetCategorieForte
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE;
    
END STATISTIQUES;

--------------------
-- BODY PACKAGE
--------------------
create or replace PACKAGE BODY STATISTIQUES AS

  PROCEDURE IncrScore
    ( 
        P_codeCategorie Categories.codeCategorie%TYPE,
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) AS
    nbPoints Number;
  BEGIN 
    SELECT COUNT(*) INTO nbPoints FROM Scores WHERE codeCategorie = P_codeCategorie AND aliasJoueur = P_aliasJoueur;
    IF nbPoints = 0 THEN
        INSERT INTO Scores VALUES(P_codeCategorie, P_aliasJoueur, 1, 'Y');
    ELSE 
        SELECT score INTO nbPoints FROM Scores WHERE codeCategorie = P_codeCategorie AND aliasJoueur = P_aliasJoueur;
        UPDATE Scores SET score = nbPoints + 1, gagnee = 'Y' WHERE codeCategorie = P_codeCategorie AND aliasJoueur = P_aliasJoueur;
    END IF;
  END IncrScore;
  
  PROCEDURE ResetCategoriesGagnee AS
  BEGIN
    UPDATE Scores SET gagnee = 'N';
  END ResetCategoriesGagnee;

  FUNCTION GetScoresJoueur
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_SCORE AS
    resultat ENR_SCORE;
  BEGIN
    OPEN resultat FOR SELECT * FROM Scores WHERE P_aliasJoueur = aliasJoueur;
    RETURN resultat;
    CLOSE resultat;
  END GetScoresJoueur;

  FUNCTION GetCategoriesGagnees
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE AS
    resultat ENR_CATEGORIE;
  BEGIN
    OPEN resultat FOR SELECT C.nom, J.nom, prenom FROM Scores S
        INNER JOIN Joueurs J ON S.aliasJoueur = J.aliasJoueur
        INNER JOIN Categories C ON S.codeCategorie = C.codeCategorie
        WHERE gagnee = 'Y';
    RETURN resultat;
    CLOSE resultat;
  END GetCategoriesGagnees;

  FUNCTION GetCategorieFaible 
    (
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE AS
    resultat ENR_CATEGORIE;
    scoreMin Number;
  BEGIN
    SELECT MIN(score) INTO scoreMin FROM Scores WHERE P_aliasJoueur = aliasJoueur;
    OPEN resultat FOR SELECT codeCategorie FROM Scores WHERE score = scoreMin;
    RETURN resultat;
    CLOSE resultat;
  END GetCategorieFaible;

  FUNCTION GetCategorieForte
    ( 
        P_aliasJoueur Joueurs.aliasJoueur%TYPE
    ) RETURN ENR_CATEGORIE AS
    resultat ENR_CATEGORIE;
    scoreMax Number;
  BEGIN
    SELECT MAX(score) INTO scoreMax FROM Scores WHERE P_aliasJoueur = aliasJoueur;
    OPEN resultat FOR SELECT codeCategorie FROM Scores WHERE score = scoreMax;
    RETURN resultat;
    CLOSE resultat;
  END GetCategorieForte; 

END STATISTIQUES;
