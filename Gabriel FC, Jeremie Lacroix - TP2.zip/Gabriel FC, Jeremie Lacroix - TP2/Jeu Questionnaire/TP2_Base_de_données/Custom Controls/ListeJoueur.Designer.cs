﻿namespace Custom_Controls
{
    partial class ListeJoueur
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.FLP_Content = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // FLP_Content
            // 
            this.FLP_Content.AutoSize = true;
            this.FLP_Content.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.FLP_Content.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.FLP_Content.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_Content.Location = new System.Drawing.Point(0, 0);
            this.FLP_Content.Margin = new System.Windows.Forms.Padding(0);
            this.FLP_Content.Name = "FLP_Content";
            this.FLP_Content.Size = new System.Drawing.Size(0, 0);
            this.FLP_Content.TabIndex = 0;
            // 
            // ListeJoueur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.FLP_Content);
            this.Name = "ListeJoueur";
            this.Size = new System.Drawing.Size(0, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel FLP_Content;
    }
}
