﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP2_Base_de_données
{
    public partial class DLG_Classement : Form
    {
        // TODO : Faire si le temps
        public DLG_Classement()
        {
            InitializeComponent();
        }
    }
}
