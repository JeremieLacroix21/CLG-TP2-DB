﻿namespace TP2_Base_de_données
{
    partial class DLG_Stats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LAB_Prenom = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LAB_Alias = new System.Windows.Forms.Label();
            this.LAB_Nom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LAB_CatFaible = new System.Windows.Forms.Label();
            this.FLP_Categories = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.PB_Art = new System.Windows.Forms.ProgressBar();
            this.LAB_PointsArt = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.PB_Géo = new System.Windows.Forms.ProgressBar();
            this.LAB_PointsGéo = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.PB_His = new System.Windows.Forms.ProgressBar();
            this.LAB_PointsHis = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.PB_Spo = new System.Windows.Forms.ProgressBar();
            this.LAB_PointsSpo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.LAB_CatForte = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DUD_Gagnees = new System.Windows.Forms.DomainUpDown();
            this.DUD_AGagner = new System.Windows.Forms.DomainUpDown();
            this.FLP_Categories.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LAB_Prenom
            // 
            this.LAB_Prenom.AutoEllipsis = true;
            this.LAB_Prenom.AutoSize = true;
            this.LAB_Prenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAB_Prenom.Location = new System.Drawing.Point(92, 56);
            this.LAB_Prenom.MaximumSize = new System.Drawing.Size(150, 20);
            this.LAB_Prenom.Name = "LAB_Prenom";
            this.LAB_Prenom.Size = new System.Drawing.Size(126, 18);
            this.LAB_Prenom.TabIndex = 11;
            this.LAB_Prenom.Text = "Prenom du joueur";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Alias :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nom :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "Prenom :";
            // 
            // LAB_Alias
            // 
            this.LAB_Alias.AutoEllipsis = true;
            this.LAB_Alias.AutoSize = true;
            this.LAB_Alias.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAB_Alias.Location = new System.Drawing.Point(92, 12);
            this.LAB_Alias.MaximumSize = new System.Drawing.Size(150, 20);
            this.LAB_Alias.Name = "LAB_Alias";
            this.LAB_Alias.Size = new System.Drawing.Size(109, 18);
            this.LAB_Alias.TabIndex = 9;
            this.LAB_Alias.Text = "Alias du Joueur";
            // 
            // LAB_Nom
            // 
            this.LAB_Nom.AutoEllipsis = true;
            this.LAB_Nom.AutoSize = true;
            this.LAB_Nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAB_Nom.Location = new System.Drawing.Point(92, 33);
            this.LAB_Nom.MaximumSize = new System.Drawing.Size(150, 20);
            this.LAB_Nom.Name = "LAB_Nom";
            this.LAB_Nom.Size = new System.Drawing.Size(106, 18);
            this.LAB_Nom.TabIndex = 10;
            this.LAB_Nom.Text = "Nom du joueur";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 18);
            this.label5.TabIndex = 12;
            this.label5.Text = "Faiblesse :";
            // 
            // LAB_CatFaible
            // 
            this.LAB_CatFaible.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LAB_CatFaible.AutoEllipsis = true;
            this.LAB_CatFaible.AutoSize = true;
            this.LAB_CatFaible.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAB_CatFaible.Location = new System.Drawing.Point(96, 231);
            this.LAB_CatFaible.MaximumSize = new System.Drawing.Size(150, 20);
            this.LAB_CatFaible.Name = "LAB_CatFaible";
            this.LAB_CatFaible.Size = new System.Drawing.Size(108, 18);
            this.LAB_CatFaible.TabIndex = 15;
            this.LAB_CatFaible.Text = "Nom Faiblesse";
            // 
            // FLP_Categories
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.FLP_Categories, 2);
            this.FLP_Categories.Controls.Add(this.label10);
            this.FLP_Categories.Controls.Add(this.PB_Art);
            this.FLP_Categories.Controls.Add(this.LAB_PointsArt);
            this.FLP_Categories.Controls.Add(this.label12);
            this.FLP_Categories.Controls.Add(this.PB_Géo);
            this.FLP_Categories.Controls.Add(this.LAB_PointsGéo);
            this.FLP_Categories.Controls.Add(this.label11);
            this.FLP_Categories.Controls.Add(this.PB_His);
            this.FLP_Categories.Controls.Add(this.LAB_PointsHis);
            this.FLP_Categories.Controls.Add(this.label13);
            this.FLP_Categories.Controls.Add(this.PB_Spo);
            this.FLP_Categories.Controls.Add(this.LAB_PointsSpo);
            this.FLP_Categories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_Categories.Location = new System.Drawing.Point(1, 23);
            this.FLP_Categories.Margin = new System.Windows.Forms.Padding(0);
            this.FLP_Categories.Name = "FLP_Categories";
            this.FLP_Categories.Size = new System.Drawing.Size(331, 119);
            this.FLP_Categories.TabIndex = 42;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 7);
            this.label10.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label10.MinimumSize = new System.Drawing.Size(90, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 18);
            this.label10.TabIndex = 29;
            this.label10.Text = "Art et culture";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PB_Art
            // 
            this.PB_Art.Location = new System.Drawing.Point(101, 5);
            this.PB_Art.Margin = new System.Windows.Forms.Padding(5, 5, 0, 0);
            this.PB_Art.Maximum = 20;
            this.PB_Art.Name = "PB_Art";
            this.PB_Art.Size = new System.Drawing.Size(184, 23);
            this.PB_Art.Step = 1;
            this.PB_Art.TabIndex = 27;
            this.PB_Art.Value = 20;
            // 
            // LAB_PointsArt
            // 
            this.LAB_PointsArt.AutoSize = true;
            this.LAB_PointsArt.Location = new System.Drawing.Point(292, 7);
            this.LAB_PointsArt.Margin = new System.Windows.Forms.Padding(7, 7, 2, 2);
            this.LAB_PointsArt.Name = "LAB_PointsArt";
            this.LAB_PointsArt.Size = new System.Drawing.Size(32, 18);
            this.LAB_PointsArt.TabIndex = 31;
            this.LAB_PointsArt.Text = "000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 33);
            this.label12.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label12.MinimumSize = new System.Drawing.Size(90, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 18);
            this.label12.TabIndex = 33;
            this.label12.Text = "Geographie";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PB_Géo
            // 
            this.PB_Géo.Location = new System.Drawing.Point(101, 33);
            this.PB_Géo.Margin = new System.Windows.Forms.Padding(5, 5, 0, 0);
            this.PB_Géo.Maximum = 20;
            this.PB_Géo.Name = "PB_Géo";
            this.PB_Géo.Size = new System.Drawing.Size(184, 23);
            this.PB_Géo.Step = 1;
            this.PB_Géo.TabIndex = 32;
            this.PB_Géo.Value = 16;
            // 
            // LAB_PointsGéo
            // 
            this.LAB_PointsGéo.AutoSize = true;
            this.LAB_PointsGéo.Location = new System.Drawing.Point(292, 35);
            this.LAB_PointsGéo.Margin = new System.Windows.Forms.Padding(7, 7, 2, 2);
            this.LAB_PointsGéo.Name = "LAB_PointsGéo";
            this.LAB_PointsGéo.Size = new System.Drawing.Size(32, 18);
            this.LAB_PointsGéo.TabIndex = 34;
            this.LAB_PointsGéo.Text = "000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 63);
            this.label11.Margin = new System.Windows.Forms.Padding(3, 7, 3, 0);
            this.label11.MinimumSize = new System.Drawing.Size(90, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 18);
            this.label11.TabIndex = 36;
            this.label11.Text = "Histoire";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PB_His
            // 
            this.PB_His.Location = new System.Drawing.Point(101, 61);
            this.PB_His.Margin = new System.Windows.Forms.Padding(5, 5, 0, 0);
            this.PB_His.Maximum = 20;
            this.PB_His.Name = "PB_His";
            this.PB_His.Size = new System.Drawing.Size(184, 23);
            this.PB_His.Step = 1;
            this.PB_His.TabIndex = 35;
            this.PB_His.Value = 4;
            // 
            // LAB_PointsHis
            // 
            this.LAB_PointsHis.AutoSize = true;
            this.LAB_PointsHis.Location = new System.Drawing.Point(292, 63);
            this.LAB_PointsHis.Margin = new System.Windows.Forms.Padding(7, 7, 2, 2);
            this.LAB_PointsHis.Name = "LAB_PointsHis";
            this.LAB_PointsHis.Size = new System.Drawing.Size(32, 18);
            this.LAB_PointsHis.TabIndex = 37;
            this.LAB_PointsHis.Text = "000";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 89);
            this.label13.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label13.MinimumSize = new System.Drawing.Size(90, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 18);
            this.label13.TabIndex = 39;
            this.label13.Text = "Sport";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PB_Spo
            // 
            this.PB_Spo.Location = new System.Drawing.Point(101, 89);
            this.PB_Spo.Margin = new System.Windows.Forms.Padding(5, 5, 0, 0);
            this.PB_Spo.Maximum = 20;
            this.PB_Spo.Name = "PB_Spo";
            this.PB_Spo.Size = new System.Drawing.Size(184, 23);
            this.PB_Spo.Step = 1;
            this.PB_Spo.TabIndex = 38;
            this.PB_Spo.Value = 19;
            // 
            // LAB_PointsSpo
            // 
            this.LAB_PointsSpo.AutoSize = true;
            this.LAB_PointsSpo.Location = new System.Drawing.Point(292, 91);
            this.LAB_PointsSpo.Margin = new System.Windows.Forms.Padding(7, 7, 2, 2);
            this.LAB_PointsSpo.Name = "LAB_PointsSpo";
            this.LAB_PointsSpo.Size = new System.Drawing.Size(32, 18);
            this.LAB_PointsSpo.TabIndex = 40;
            this.LAB_PointsSpo.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(4, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 21);
            this.label4.TabIndex = 43;
            this.label4.Text = "Catégorie";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(170, 1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 21);
            this.label6.TabIndex = 44;
            this.label6.Text = "Victoires Totales";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.FLP_Categories, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 262);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.44715F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 84.55285F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(333, 143);
            this.tableLayoutPanel1.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 204);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 18);
            this.label7.TabIndex = 46;
            this.label7.Text = "Force :";
            // 
            // LAB_CatForte
            // 
            this.LAB_CatForte.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LAB_CatForte.AutoEllipsis = true;
            this.LAB_CatForte.AutoSize = true;
            this.LAB_CatForte.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LAB_CatForte.Location = new System.Drawing.Point(96, 204);
            this.LAB_CatForte.MaximumSize = new System.Drawing.Size(150, 20);
            this.LAB_CatForte.Name = "LAB_CatForte";
            this.LAB_CatForte.Size = new System.Drawing.Size(84, 18);
            this.LAB_CatForte.TabIndex = 47;
            this.LAB_CatForte.Text = "Nom Force";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(76, 168);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(181, 20);
            this.label14.TabIndex = 48;
            this.label14.Text = "Statistiques Globales";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(100, 89);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 20);
            this.label15.TabIndex = 49;
            this.label15.Text = "Partie en Cours";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 110);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 18);
            this.label17.TabIndex = 51;
            this.label17.Text = "Gagnées :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 133);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 18);
            this.label18.TabIndex = 52;
            this.label18.Text = "À Gagner :";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(-5, 85);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(349, 1);
            this.panel1.TabIndex = 53;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(0, 165);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(349, 1);
            this.panel2.TabIndex = 54;
            // 
            // DUD_Gagnees
            // 
            this.DUD_Gagnees.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DUD_Gagnees.Location = new System.Drawing.Point(95, 110);
            this.DUD_Gagnees.Name = "DUD_Gagnees";
            this.DUD_Gagnees.Size = new System.Drawing.Size(226, 22);
            this.DUD_Gagnees.TabIndex = 57;
            // 
            // DUD_AGagner
            // 
            this.DUD_AGagner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DUD_AGagner.Location = new System.Drawing.Point(95, 133);
            this.DUD_AGagner.Name = "DUD_AGagner";
            this.DUD_AGagner.Size = new System.Drawing.Size(226, 22);
            this.DUD_AGagner.TabIndex = 58;
            // 
            // DLG_Stats
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(333, 405);
            this.Controls.Add(this.DUD_AGagner);
            this.Controls.Add(this.DUD_Gagnees);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.LAB_CatForte);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.LAB_CatFaible);
            this.Controls.Add(this.LAB_Prenom);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LAB_Alias);
            this.Controls.Add(this.LAB_Nom);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DLG_Stats";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DLG_Stats";
            this.FLP_Categories.ResumeLayout(false);
            this.FLP_Categories.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LAB_Prenom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LAB_Alias;
        private System.Windows.Forms.Label LAB_Nom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LAB_CatFaible;
        private System.Windows.Forms.FlowLayoutPanel FLP_Categories;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar PB_Art;
        private System.Windows.Forms.Label LAB_PointsArt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ProgressBar PB_Géo;
        private System.Windows.Forms.Label LAB_PointsGéo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ProgressBar PB_His;
        private System.Windows.Forms.Label LAB_PointsHis;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ProgressBar PB_Spo;
        private System.Windows.Forms.Label LAB_PointsSpo;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label LAB_CatForte;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DomainUpDown DUD_Gagnees;
        private System.Windows.Forms.DomainUpDown DUD_AGagner;
    }
}